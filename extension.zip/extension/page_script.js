(function () {
    window.screenshotExtensionAvailable = true;
    window.dispatchEvent(new Event('screenshotExtensionReady'));
})();
